// 2025 Kristoffer

#ifndef _TOTAVG_H_
#define _TOTAVG_H_

double total(double arr[], int n);
double average(double arr[], int n);

#endif /* _TOTAVG_H_ */
