// 2025 Kristoffer

#include "libmult.h"

int triple(int x) {
  return 3 * x;
}

int quadruple(int x) {
  return 4 * x;
}

int quintuple(int x) {
  return 5 * x;
}

int sixtuple(int x) {
  return 6 * x;
}

int septuple(int x) {
  return 7 * x;
}
