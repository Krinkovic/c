// 2025 Kristoffer

#ifndef _MAXMIN_H_
#define _MAXMIN_H_

int minimum(int arr[], int n);
int maximum(int arr[], int n);

#endif /* _MAXMIN_H_ */
